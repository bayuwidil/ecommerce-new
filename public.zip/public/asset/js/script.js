$(document).ready(function(){
    $('.slider').slick({
      autoplay: true,
      autoplaySpeed: 2500,
    });
  });

  
