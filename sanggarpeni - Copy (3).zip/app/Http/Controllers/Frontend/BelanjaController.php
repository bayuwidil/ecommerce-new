<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Detail_Pembelian;
use App\Models\Pembelian;
use Illuminate\Support\Facades\Auth;

class BelanjaController extends Controller
{
    public function index(){
        $beli = Pembelian::where('id_user', Auth::id())->get();
        return view('frontend.riwayat-belanja', compact('beli'));
    }

    public function view($id){
        $beli = Pembelian::where('id', $id)->where('id_user', Auth::id())->first();
        $detail_pembelian = Detail_Pembelian::where('id_pembelian',$beli->id)->get();
        return view('frontend.viewbelanja', compact('beli','detail_pembelian'));
    }
}
 