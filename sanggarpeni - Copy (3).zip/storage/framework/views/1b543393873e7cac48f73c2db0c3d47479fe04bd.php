

<?php $__env->startSection('content'); ?> 
        <div class="container mb-4">
            <div class="row row-produk">
                <h3 class="mb-3 mt-4 fw-semibold text-brown">Wishlist <span id="explore"></span></h3>
                <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12" id="table-scroll">
                    <?php if($wishlist->count() > 0): ?>
                    <?php $__currentLoopData = $wishlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-4 col-sm-4 col-6 mx-1" id="produk-col">
                        <div class="card card-product text-center shadow-sm">
                        <svg height="50" width="200" style="position:absolute;">
                                    <ellipse cx="140" cy="12" rx="12" ry="12"
                                    style="fill:white; margin-left:80%; position:absolute;" />
                                    </svg>
                            <a href="<?php echo e(url('detail-prod/'.$item->product->id)); ?>" class="text-decoration-none text-one">
                                <img src="<?php echo e(asset('asset/uploads/product/'.$item->product->image)); ?>" class="card-img-top" alt="...">
                                <div class="card-body text-start">
                                    <div class="category-text bg-brown ps-1">
                                        <a href="#" class=" card-info text-decoration-none text-three"><?php echo e($item->product->category->nama_kategori); ?></a></p>
                                    </div>
                                    <div id="more-char">
                                        <span class="fw-semibold text-one"><?php echo e($item->product->name); ?></span>
                                    </div>
                                    <p class="fw-bold my-2 text-one" style="font-size: 1rem;">Rp.<?php echo e(number_format($item->product->harga)); ?>,-</p>
                                    <p class="sm card-info text-two m-0" style="font-size: .7rem;"> SanggarPeni</p>
                                    <button class="btn " style="position:absolute; left:79.5%; bottom:89%;"><a href="<?php echo e(url('hapus-wish/'.$item->id)); ?>" style="color:brown;" ><i class="fa fa-regular fa-trash" style="" ></i></a></button>
                                </div>
                            </a>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php else: ?>
                    <h4>Tidak ada Produk di Wishlist</h4>
                    <?php endif; ?>                 
                </div>
                

            </div>
        </div>
        
    <?php $__env->stopSection(); ?>
    

<?php echo $__env->make('layouts.inc.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Yubayu\Documents\Project\sanggarpeni-Copy\resources\views/frontend/wishlist.blade.php ENDPATH**/ ?>