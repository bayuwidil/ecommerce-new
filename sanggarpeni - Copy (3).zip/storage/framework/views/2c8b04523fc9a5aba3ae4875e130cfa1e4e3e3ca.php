

<?php $__env->startSection('content'); ?>
<h3><?php echo e($category->nama_kategori); ?></h3>
<section class="banner-part mt-2 mb-5">
    <div class="row text-center row-bagr ">
                <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-4 col-sm-4 col-6 mx-1" id="produk-col">
                        <div class="card card-product text-center shadow-sm">
                            <a href="<?php echo e(url('detail-prod/'.$item->id)); ?>" class="text-decoration-none text-one">
                                <img src="<?php echo e(asset('asset/uploads/product/'.$item->image)); ?>" class="card-img-top" alt="...">
                                <div class="card-body text-start">
                                    <div class="category-text bg-brown ps-1">
                                        <a href="#" class=" card-info text-decoration-none text-three"><?php echo e($category->nama_kategori); ?></a></p>
                                    </div>
                                    <div id="more-char">
                                        <span class="fw-semibold text-one"><?php echo e($item->name); ?></span>
                                    </div>
                                    <p class="fw-bold my-2 text-one" style="font-size: 1rem;">Rp.<?php echo e($item->harga); ?>,-</p>
                                    <p class="card-info text-two m-0" style="font-size: .7rem;"><i class='bx bxs-star text-warning'></i> 5.0 | Terjual 122</p>
                                </div>
                            </a>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.inc.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Yubayu\Documents\.TA\sanggarpeni - Copy (3)\resources\views/Frontend/kategori.blade.php ENDPATH**/ ?>