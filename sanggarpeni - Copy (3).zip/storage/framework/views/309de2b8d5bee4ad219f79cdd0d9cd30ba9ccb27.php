

<?php $__env->startSection('content'); ?>
<section class="py-5 mb-5">
        <div class="container">
            <h3 class="mb-3 fw-semibold text-brown">Data Produk <span></span></h3>
            <div class="my-2">
                <a href="<?php echo e(url('add-product')); ?>" class="btn" id="change-2">
                    <div class="d-flex justify-content-center align-items-center">
                        <i class='bx bx-plus fw-bolder me-2' ></i>
                        <span>Tambah</span>
                    </div>
                </a>
                <a href="<?php echo e(url('ekspor-product')); ?>" class="btn" id="change-3">
                    <div class="d-flex justify-content-center align-items-center">
                        <i class='bx bx-download fw-bold me-2' ></i>
                        <span>Export</span>
                    </div>
                </a>
            </div>
            <div class="row table-data">
                <div class="col-12">
                    <div class="data_table" style="font-size: rem;">
                        <table id="index" class="table ">
                            <thead class="text-five">
                                <tr>
                                    <th>Nama</th>
                                    <th>Kategori</th>
                                    <th>Harga</th>
                                    <th>Berat</th>
                                    <th>Material</th>
                                    <th>Size</th>
                                    <th>Pelapis</th>
                                    <th>Foto</th>
                                    <th>Deskripsi</th>
                                    <th>Stok</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td style="width: 100px;"><?php echo e($item->name); ?></td>
                                    <td><?php echo e($item->category->nama_kategori); ?></td>
                                    <td><?php echo e($item->harga); ?></td>
                                    <td><?php echo e($item->berat); ?></td>
                                    <td><?php echo e($item->material); ?></td>
                                    <td><?php echo e($item->size); ?></td>
                                    <td><?php echo e($item->pelapis); ?></td>
                                    <td><img src="<?php echo e(asset('asset/uploads/product/'.$item->image)); ?>" class="cate-image" alt="image here" ></td>
                                    <td><?php echo htmlspecialchars_decode (nl2br($item->deskripsi)); ?></td>
                                    <td><?php echo e($item->stok); ?></td>
                                    <td>
                                        <div class="action d-flex justify-content-center align-items-center">
                                            <a href="<?php echo e(url('edit-produk/'.$item->id)); ?>"><i class='bx bx-edit text-green fs-3'></i></a>
                                            <a href="<?php echo e(url('delete-product/'.$item->id)); ?>"><i class='bx bxs-trash text-red fs-3' ></i></a>
                                        </div>

                                    </td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <script>
        $(document).ready(function(){
            var table = $('#example').DataTable({
                
                
                
            });
            
            table.buttons().container()
            .appendTo('#example_wrapper .col-md-6:eq(0)');

        });
    </script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\project\sanggarpeni\resources\views/admin/products/index.blade.php ENDPATH**/ ?>