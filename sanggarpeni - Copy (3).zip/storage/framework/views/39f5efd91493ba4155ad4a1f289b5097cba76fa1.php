

<?php $__env->startSection('content'); ?>
    <div class="card">
        <h1>Dashboard</h1>
    </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\project\sanggarpeni\resources\views/Admin/index.blade.php ENDPATH**/ ?>