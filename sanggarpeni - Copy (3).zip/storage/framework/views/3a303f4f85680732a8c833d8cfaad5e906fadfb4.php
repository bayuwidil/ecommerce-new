

<?php $__env->startSection('content'); ?>
<div class="container">
            <h3 class="mb-3 fw-semibold text-brown">Laporan Penjualan <span id="explore"></span></h3>
            <div class="my-2">

            </div>

            <div class="row table-data">
                <div class="col-12">
                    <div class="data_table" style="font-size: rem;">
                        <table id="kategori" class="table ">
                            <thead class="text-five">
                                <tr>
                                    <th>No</th>
                                    <th>Kategori</th>
                                    <th>Gambar</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                           
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Yubayu\Documents\.TA\sanggarpeni - Copy (3)\resources\views/admin/pembelian/report.blade.php ENDPATH**/ ?>