

<?php $__env->startSection('content'); ?> 
<div class="container">
            <?php 
            $total = 0;
            $berat = 0;
            $jumlah = 0;
            ?>
            <div class="row row-produk">
                <h3 class="mb-3 mt-4 fw-semibold text-brown">Daftar Riwayat Pesanan <span id="explore"></span></h3>
                

                <div class="col-lg-12 col-md-4 col-sm-12 col-xs-8">
                    <div class="count p-3 border rounded-3 shadow-set text-one">
                        
                            <div class="calculator p-3">
                                <table class="table text-center">
                                    <thead class="text-two">
                                        <tr>
                                            <th scope="col" class="text-start fw-normal py-3">Kode Pesanan</th>
                                            <th scope="col" class="fw-normal py-3">Nama Penerima</th>
                                            <th scope="col" class="fw-normal py-3">Alamat</th>
                                            <th scope="col" class="fw-normal py-3">status</th>
                                            <th scope="col" class="fw-normal py-3">Total</th>
                                            <th></th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        
                                            <?php $__currentLoopData = $pesan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($item->kode_transaksi); ?></td>
                                                    <td><?php echo e($item->name); ?></td>
                                                    <td><?php echo e($item->alamat); ?></td>
                                                    <td><?php echo e($item->status == '0' ?'menunggu pembayaran' :'Dalam Pengiriman'); ?></td>'
                                                    <td>Rp.<?php echo e(number_format($item->total)); ?></td>
                                                    <td>
                                                        <a href="<?php echo e(url('view-pesan/'.$item->id)); ?>" class="btn btn-hover">Detail</a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                        
                                    </tbody>
                                </table>
                            </div>
                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.inc.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Yubayu\Documents\Project\sanggarpeni - Copy\resources\views/frontend/riwayat-belanja.blade.php ENDPATH**/ ?>