<?php echo e($slot); ?>

<?php /**PATH C:\Users\Yubayu\Documents\.TA\sanggarpeni\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>