

<?php $__env->startSection('content'); ?>
    <div class="row">
            <h2 class="mb-3 fw-normal text-six">Dashboard<span id="explore"></span></h2>                        
            <div class="col-sm-6 col-md-6 col-lg-6 col-xl-3 mb-3">
                <div class="card bg-white text-white border-0 shadow-sm text-two box-info">
                    <div class="card-body text-two p-3">
                        <div class="out bg-lightbrown rounded-5 mb-3 d-flex justify-content-center align-items-center text-six" id="image-height">
                            <i class="fa-solid fa-list-ul"></i>
                        </div>
                        <p class="size-p mb-1">Jumlah Kategori</p>
                        <h3 class="fw-bolder mb-0"><?php echo e($kategori); ?></h3>
                        <p class="size-p mb-0 mt-1"></p>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-6 col-lg-6 col-xl-3 mb-3">
                <div class="card bg-white text-white border-0 shadow-sm text-two box-info">
                    <div class="card-body text-two p-3">
                        <div class="out bg-lightbrown rounded-5 mb-3 d-flex justify-content-center align-items-center text-six" id="image-height">
                            <i class="fa-solid fa-box-archive"></i>
                        </div>
                        <p class="size-p mb-1">Jumlah Produk</p>
                        <h3 class="fw-bolder mb-0"><?php echo e($produk); ?></h3>
                        <p class="size-p mb-0 mt-1"></p>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-6 col-lg-6 col-xl-3 mb-3">
                <div class="card bg-white text-white border-0 shadow-sm text-two box-info">
                    <div class="card-body text-two p-3">
                        <div class="out bg-lightbrown rounded-5 mb-3 d-flex justify-content-center align-items-center text-six" id="image-height">
                            <i class="fa-solid fa-cart-shopping"></i>
                        </div>
                        <p class="size-p mb-1">Jumlah Pesanan</p>
                        <h3 class="fw-bolder mb-0"><?php echo e($pesanan); ?></h3>
                        <p class="size-p mb-0 mt-1"></p>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-6 col-lg-6 col-xl-3 mb-3">
                <div class="card bg-white text-white border-0 shadow-sm text-two box-info">
                    <div class="card-body text-two p-3">
                        <div class="out bg-lightbrown rounded-5 mb-3 d-flex justify-content-center align-items-center text-six" id="image-height">
                            <i class="fa-solid fa-user"></i>
                        </div>
                        <p class="size-p mb-1">Jumlah Customer</p>
                        <h3 class="fw-bolder mb-0"><?php echo e($user); ?></h3>
                        <p class="size-p mb-0 mt-1"></p>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Yubayu\Documents\Project\sanggarpeni\resources\views/Admin/index.blade.php ENDPATH**/ ?>