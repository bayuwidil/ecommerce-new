

<?php $__env->startSection('content'); ?>
<section class="py-5 mb-5">
        <div class="container">
            <h3 class="mb-3 fw-semibold text-brown">Data Produk <span></span></h3>
            <div class="my-2">
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="data_table">
                        <table id="example" class="table table-striped table-bordered">
                            <thead class="bg-brown">
                                <tr>
                                    <th>No</th>
                                    <th>Kode Pesanan</th>
                                    <th>Nama Penerima</th>
                                    <th>Alamat</th>
                                    <th>status</th>
                                    <th>Total</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $no=1; ?>
                            <?php $__currentLoopData = $pesan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    <td><?php echo e($item->kode_transaksi); ?></td>
                                    <td><?php echo e($item->name); ?></td>
                                    <td><?php echo e($item->alamat); ?></td>
                                    <td><?php echo e($item->status == '0' ?'menunggu pembayaran' :'Dalam Pengiriman'); ?></td>
                                    <td>Rp.<?php echo e(number_format($item->total)); ?></td>
                                    <td>
                                        <a href="<?php echo e(url('adminview-pesan/'.$item->id)); ?>" class="btn btn-hover" style="background-color: white ">Detail</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <script>
        $(document).ready(function(){
            var table = $('#example').DataTable({
                
                
                
            });
            
            table.buttons().container()
            .appendTo('#example_wrapper .col-md-6:eq(0)');

        });
    </script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Yubayu\Documents\Project\sanggarpeni\resources\views/admin/pesanan/index.blade.php ENDPATH**/ ?>