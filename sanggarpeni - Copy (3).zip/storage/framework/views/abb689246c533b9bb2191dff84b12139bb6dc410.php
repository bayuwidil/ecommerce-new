<?php $__env->startSection('content'); ?>
<section class="py-3 vh-75">
        <div class="container d-flex justify-content-center align-items-center mb-3">
        </div>
        <div class="container h-100">
            <div class="row d-flex justify-content-center align-items-center h-100">
                <div class="col-12 col-md-8 col-lg-6 col-xl-5">
                    <div class="card bg-white shadow-sm" style="border-radius: 1rem;">
                        <div class="card-body p-5 text-center">
                            <div class="mb-3">
                                <h4 class="fw-bold text-one mb-3">Masuk Akun</h3>
                                <p class="text-two">Belum punya akun di Sanggarpeni ? <a href="<?php echo e(route('register')); ?>" class="text-decoration-none text-five fw-bold">Daftar</a></p>
                            </div>
                            <div class="row">
                            <form method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>
                                        <div class="col-md-12 mb-3" style="text-align:left;">
                                            <label for="validationDefault01" class="form-label label-sign text-two" ><?php echo e(__('Email Address')); ?></label>
                                            <input type="email" class="form-control text-two bg-white shadow-sm <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" id="validationDefault01" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-md-12 mb-3" style="text-align:left;">
                                            <label for="validationDefault02" class="form-label label-sign text-two"><?php echo e(__('Password')); ?></label>
                                            <input type="password" class="form-control text-two bg-white shadow-sm no-outline border-1 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" id="validationDefault01" required autocomplete="current-password">
                                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="col-md-12 mb-3 d-flex justify-content-between">
                                            <div class="remember d-flex justify-content-between">
                                                <input type="checkbox" value="" class="remember me-1" id="checkbox">
                                                <label class="text-two" for="checkbox">
                                                    Ingat Saya !
                                                </label>
                                            </div>

                                            <?php if(Route::has('password.request')): ?>
                                                <a class="text-decoration-none text-five fw-normal" href="<?php echo e(route('password.request')); ?>">
                                                    <?php echo e(__('Forgot Your Password?')); ?>

                                                </a>
                                            <?php endif; ?>
                                        </div>

                                        <div class="col-md-12 d-grid gap-2 mb-3 py-1">
                                            <button class="btn btn-sign fw-semibold fs-6" type="submit">Masuk</button>
                                        </div>
                                        <div class="col-md-12 d-grid gap-2" style="margin-bottom: -3px;">
                                            <p class="horizontal-line text-two label-sign">Atau masuk dengan</p>
                                        </div>
                                        <div class="col-md-12 d-grid gap-2 w-100 py-1">
                                            <a href="<?php echo e(route('google.login')); ?>" class="btn text-one fw-semibold fs-6 d-flex justify-content-center align-items-center w-100" id="btn-google">
                                                <img src="../asset/img/google-logo.png" class="me-2" style="height: 20px;" alt=""> 
                                                Sign in with Google
                                            </a>
                                        </div>
                                </form>	
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Yubayu\Documents\Project\sanggarpeni - Copy\resources\views/auth/login.blade.php ENDPATH**/ ?>