

<?php $__env->startSection('content'); ?> 
   
<div class="container">
    <?php 
    $total=0;
    ?>
    <div class="row">
            <div class="row row-produk">
                <h3 class="mb-3 mt-4 fw-semibold text-brown">Checkout<span id="explore"></span></h3>
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 text-one text-one">
                    <form method="post" action="<?php echo e(url('detail-pesanan')); ?>">
                        <?php echo csrf_field(); ?>
                    <div class="form-checkout shadow-set p-3 border rounded-3">
                        <div class="shipment">
                            <h6 class="fw-bold">Masukan Detail Pengiriman:</h6>
                            <div class="address ms-3">
                            <div class="col-md-12 mb-3">
                            <label for="validationDefault01" class="form-label fw-semibold text-one">Nama </label>
                            <input type="text" class="form-control text-two" name="penerima" id="validationDefault01" value="<?php echo e(Auth::user()->name); ?>">
                        </div>
                        <div class="col-md-12 mb-3" hidden="true">
                                <label for="validationDefault01" class="form-label fw-semibold text-one">No Pembelian</label>
                                <input type="text" class="form-control text-two" name="no_pembelian" id="validationDefault01" value="<?php echo e('KP-'.date('dmy').'-'.$kt); ?>" readonly>
                        </div>
                        <div class="col-md-12 mb-3" hidden="true">
                                <label for="validationDefault01" class="form-label fw-semibold text-one">Tanggal Pembelian</label>
                                <input type="date" class="form-control text-two" name="tgl_pembelian" id="validationDefault01" value="<?php echo date('Y-m-d'); ?>" readonly>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="validationDefault01" class="form-label fw-semibold text-one">Email </label>
                            <input type="email" class="form-control text-two" name="email" id="validationDefault01" value="<?php echo e(Auth::user()->email); ?>" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="validationDefault02" class="form-label fw-semibold text-one">Telepon</label>
                            <input type="text" class="form-control text-two" name="telepon" id="validationDefault02" value="<?php echo e(Auth::user()->telepon); ?>" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold text-one">Provinsi</label>
                            <select class="form-control provinsi-tujuan" name="province_destination">
                                <option value="0">-- pilih provinsi tujuan --</option>
                                <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($province); ?>"><?php echo e($value); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold text-one">Kota/Kabupaten</label>
                            <select class="form-control kota-tujuan" name="city_destination">
                                <option value="">-- pilih kota tujuan --</option>
                            </select>
                        </div>
                        <div class="col-md-12">
                            <label for="validationDefault02" class="form-label fw-semibold text-one">Detail Alamat Lengkap</label>
                            <textarea class="form-control text-two shadow-sm" placeholder="Leave a comment here" name="alamat" style="min-height: 100px" required>
                            <?php echo e(Auth::user()->alamat); ?>

                            </textarea>
                        </div>
                        <!-- asal -->
                        
                            
                            <!-- <select class="form-control provinsi-asal" name="province_origin" hidden="true">
                                <option value="5" >DI Yogyakarta</option>
                                
                            </select>
                        
                            <select class="form-control kota-asal" name="city_origin" hidden="true">
                                <option value="501">Yogyakarta</option>
                            </select> -->
                        
                        <!-- akhir asal -->

                        <!-- tujuan -->
                        
                        <!-- akhir tujuan  -->

                        <!-- kurir -->
                        
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-semibold text-one">Pilih Jasa Pengiriman</label>
                                <select class="form-control kurir" name="courier" required>
                                    <option value="0">-- pilih kurir --</option>
                                    <option value="jne">JNE</option>
                                    <option value="pos">POS</option>
                                    <option value="tiki">TIKI</option>
                                </select>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-semibold text-one">BERAT (GRAM)</label>
                                <input type="number" class="form-control" name="weight" id="weight" placeholder="Masukkan Berat (GRAM)">    
                                <button class="btn btn-check">CEK ONGKOS KIRIM</button>
                                </div>
                                    
                            <div class="col-md-6 mb-3">
                                    <button class="btn btn-check">CEK ONGKOS KIRIM</button>
                                    
                                    </div>
                        
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <table class="table text-center">
                        <thead class="text-two">
                            <tr>
                                <th scope="col" class="text-start fw-normal py-3">Produk</th>
                                <th scope="col" class="fw-normal py-3">Jumlah</th>
                                <th scope="col" class="fw-normal py-3">Harga</th>
                            </tr>
                        </thead>
                        <tbody class="text-one">
                        <?php $__currentLoopData = $chartitem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-start fw-semibold"><img src="<?php echo e(asset('asset/uploads/product/'.$item->product->image)); ?>" class="rounded-3 shadow-sm me-2 img-sizing" alt=""><?php echo e($item->product->name); ?></td>
                                <td class="align-middle fw-semibold"><?php echo e($item->jumlah); ?></td>
                                <td class="align-middle fw-semibold">Rp.<?php echo e(number_format($item->product->harga)); ?></td>
                            </tr>
                            <?php 
                            $total += ($item->product->harga * $item->jumlah);
                            $ongkir = 20000;
                            $grand = $total + $ongkir;
                            ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="form-checkout shadow-set p-3 border rounded-3 ">
                    <div class="count">
                            <h6 class="fw-bold">Ringkasan Belanja</h6>
                            <div class="calculator p-3">
                                <table class="table text-center borderless">
                                    <tbody class="text-one">
                                        <tr>
                                            <td class="text-start fw-light text-two" colspan="2">Sub Total :</td>
                                            <td class="align-middle fw-semibold text-end">Rp.<?php echo e(number_format($total)); ?></td>
                                        </tr>
                                        <tr>
                                            <td class="text-start fw-light text-two" colspan="2">Ongkos Kirim :</td>
                                            <td class="align-middle fw-semibold text-end">Rp.<?php echo e(number_format($ongkir)); ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                                <hr>
                                <table class="table text-center borderless">
                                    <tbody class="text-one">
                                        <tr>
                                            <td class="text-start fw-light text-two" colspan="2">Total :</td>
                                            <td class="align-middle fw-semibold text-end"><input name="total" value="<?php echo e($grand); ?>" hidden="true"> Rp.<?php echo e(number_format($grand)); ?></input></td>
                                        </tr>
                                    </tbody>
                                </table>
                                <div class="paymnet-method d-flex justify-content-end">
                                    <button type="submit" class="btn btn-hover" style="margin-right: 10px;">Selanjutnya</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
                
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 text-one text-one" style="margin-top: 10px;">
                
                </div>
            </div>
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.inc.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Yubayu\Documents\.TA\sanggarpeni\resources\views/frontend/checkout.blade.php ENDPATH**/ ?>